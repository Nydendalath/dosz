The Clue!   version 1.7E +patch by MOK
Neo Software Productions 1994
Point & Click Adventure for DOS or Windows 9x
Pre-cracked.

NOTE: This copy has been patched with a patch kindly provided by Mok.
Without the patch, special memory configuration was required (DOS=HIGH, but
*not* into the UMB) or you'd get an error message saying there is not enough
XMS/UMB mem.
It should now run on most systems VIA Windows 9.x in a DOS box.


Upacking the archive:
-Just create a directory on your hard drive and unzip the download into it.
Close up your .zip extraction program.
-Change to the directory you unzipped the download into and run CLUEINST.EXE
to unpack the game. This may take a while on some systems, just be patient.

Playing the game:
Run SETUP.EXE and select "change soundcard-parameters" to configure your
sound card. When finished, select "end" from the menu.
The configuration program menu has an option to alter you autoexec.bat and
config.sys files. I suggest you do *not* select this option unless you are
familiar with DOS bootfiles.
If you need to reconfigure your sound card later, simply run SETUP.EXE again

Start the game with THECLUE!.BAT
When asked to type in words from the game manual, just hit the Enter key
and the game will continue loading.

Press the left Mouse button, the Enter key or the joystick Fire button to
select an option in the menu. By pressing the right Mouse button or the
Escape key <Esc>, the action can be cancelled anytime.

Press F1 for game options (Save, Load, Quit.)

Have fun!